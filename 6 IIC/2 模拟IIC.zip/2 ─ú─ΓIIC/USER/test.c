#include "stm32f10x.h" 
#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "stdio.h"
#include "bsp_at24c02.h"


int main(void)
{				 
	unsigned char wdata[8] = {1,2,4,8,16,32,48,64};
	unsigned char rdata[8];
	Stm32_Clock_Init(9);
	delay_init(72);
	uart_init(72,9600);
	IIC_Init();
	
	AT24C02_WriteByte(0x50,0x00,wdata,8);
	
	AT24C02_ReadByte(0x50,0x00,rdata,8);
  	while(1)
	{
		printf("0x00:%d  ", rdata[0]);
		printf("0x01:%d  ", rdata[1]);
		printf("0x02:%d  ", rdata[2]);
		printf("0x03:%d  ", rdata[3]);
		printf("0x04:%d  ", rdata[4]);
		printf("0x05:%d  ", rdata[5]);
		printf("0x06:%d  ", rdata[6]);
		printf("0x07:%d  ", rdata[7]);
		delay_ms(1000);
	}	 
} 






